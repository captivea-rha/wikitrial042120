* Go to to a project and click on "Wiki Pages" to see linked documents or to
  create new ones.
