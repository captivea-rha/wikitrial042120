This module allow to link document pages to projects.
